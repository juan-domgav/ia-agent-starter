# IA Agent Starter (Low-Cost, Railway/Render friendly)

Starter para desplegar **agentes personales** con **FastAPI** en *free tiers* (Railway/Render) y CI con **GitHub Actions**.

## Qué incluye
- FastAPI con endpoints `/health` y `/predict`.
- Dockerfile listo para Railway/Render.
- GitHub Actions: tests (y un ejemplo de deploy manual con Railway CLI).
- Estructura para crecer: `api/`, `rag/`, `eval/`, `infra/`.
- `.env.example` con variables mínimas.
  
## Requisitos locales (opcional)
- Python 3.11+
- Docker

## Ejecutar local
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r api/requirements.txt
uvicorn api.main:app --reload --port 8000
```

## Despliegue ultra-barato
1. **Crea un repositorio en GitHub** (público o privado).
2. **Conecta tu repo a Railway** (o Render) desde su panel web.
3. Railway detectará `Dockerfile` y levantará el servicio.
4. En **Variables** de la plataforma añade las de `.env.example`.

## Endpoints
- `GET /health` — estado del servicio.
- `POST /predict` — demo mínima que simula la respuesta de un agente.
