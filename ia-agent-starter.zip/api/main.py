from fastapi import FastAPI
from pydantic import BaseModel
import os

app = FastAPI(title="Personal Agent API", version="0.1.0")

class Query(BaseModel):
    prompt: str

@app.get("/health")
def health():
    return {"status": "ok", "env": os.getenv("APP_ENV", "dev")}

@app.post("/predict")
def predict(q: Query):
    reply = f"[agent] Recibido: {q.prompt}"
    return {"answer": reply}
