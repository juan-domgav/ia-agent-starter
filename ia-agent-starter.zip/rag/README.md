# Pipelines RAG (opcional)
