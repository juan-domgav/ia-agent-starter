from fastapi.testclient import TestClient
from api.main import app

client = TestClient(app)

def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert "status" in r.json()

def test_predict():
    r = client.post("/predict", json={"prompt":"hola"})
    assert r.status_code == 200
    assert "answer" in r.json()
